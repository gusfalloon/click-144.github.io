
public class Test {

	public static void main (String[] args) {
		
		String test = "startst\nanother line to see\nif there's any weird bug in this loop";
		for (int i = 0; i < test.length(); i++) {
			if (i >= test.length()-2) {
				break;
			}
			System.out.println(test.substring(i, i+3));
		}
	}
}
