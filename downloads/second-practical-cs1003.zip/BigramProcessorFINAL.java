import java.io.*;
import java.util.*;

public class BigramProcessorFINAL {

	final private int noOfNgrams = 676;	// A small request - change the noOfNgrams to be (26^n). The program spews out a bug otherwise.
	NgramInfo[] ngrams = new NgramInfo[noOfNgrams];

	private boolean isLetter(char c) {
		return c >= 'a' && c <= 'z';	// A method provided by the hints. Handy.
	}

	private String cleanWord(String word) {

		String cleaned_word = word.toLowerCase();
		
		for (int i = 0; i < word.length(); i++) {
			// Remove punctuation from the start of the word.
			while (cleaned_word.length() > 0 && !isLetter(cleaned_word.charAt(0))) {
				cleaned_word = cleaned_word.substring(1);
			}
			
			// Remove punctuation from the middle of the word. This is an extension of the cleanWord() method.
			// Seems very simple. Is only as such because I couldn't work out how else to do it - I just know that any ' is represented
			// as so in the output string, at least when I tried it. At the very least, won't include weird bigrams in the output...
			cleaned_word = cleaned_word.replace("⊙", "");

			// Remove punctuation from the end of the word.
			while (cleaned_word.length() > 0 && !isLetter(cleaned_word.charAt(cleaned_word.length()-1))) {
				cleaned_word = cleaned_word.substring(0,cleaned_word.length()-1);
			}
		}
		return cleaned_word;
	}
	
	// A very-much-appreciated method that sorts the array. Thanks awfully...
	private void sortNgrams() {
		
		// This does a bubble sort.
		// Each time round the outer loop an element moves up the array to its correct position.
		for (int i = 0; i < ngrams.length; i++) {
			for (int j = 0; j < ngrams.length - i - 1; j++) {
				if (outOfOrder(j)) swap(j);
			}
		}
	}

	private boolean outOfOrder(int j) {
		
		// We want to sort with highest count first, so two adjacent elements are out of order
		// if the count of the first one is less than that of the second one.
		return ngrams[j] != null && ngrams[j+1] != null && ngrams[j].getCount() < ngrams[j+1].getCount();
	}

	private void swap(int j) {

		NgramInfo temp = ngrams[j];
		ngrams[j] = ngrams[j+1];
		ngrams[j+1] = temp;
	}
	
	int findNgram (String ngram) {
		int position = 0;
		for (int i = 0; i < noOfNgrams; i++) {
			if(ngrams[i] == null) { // In the case where the program encounters null
				position = i;
				break;
			}
			else if ((ngrams[i].getNgram() != null) && !(ngrams[i].getNgram().equals(ngram))) { // In the case where the program encounters
				continue;																		// a non-null n-gram that isn't equivalent 
			}																					// to the one it's looking for. Just to make sure.
			else {
				position = i; // The correct ngram is found, and the loop breaks (so it doesn't waste time looking through the entire array).
				break;
			}
		}
		return position;
	}

	void recordNgram (String ngram) {
		int position = findNgram(ngram);
		if (ngrams[position] == null) {
			ngrams[position] = new NgramInfo();
			ngrams[position].setNgram(ngram); // Initialising an ngram and incrementing the count if the ngram is new.
			ngrams[position].increment();
		}
		else {
			ngrams[position].increment(); // Otherwise, only the count changes.
		}
	}
	
	void analyseWord (String word, int n) {
		for (int i = 0; i < word.length(); i++) {
			if (i >= word.length()-(n-1)) { // If the word in question isn't big enough to perform an ngram operation on it, the loop breaks.
				break;
			}
			String ngram = word.substring(i, i+n); // Otherwise, ngrams are generated and then recorded.
			recordNgram(ngram);
		}
	}
	
	// I'd just like to note that the following method, when it worked, caused me to actually cheer. This was a beautiful moment.
	
	void outputReport (PrintStream writer, int n) {
		writer.println("The value for n was: " + n); // Just to make it a bit more user-friendly. These things matter, y'know.
		writer.println("n-gram, count");
		for (int i = 0; i < noOfNgrams; i++) {
			if (ngrams[i] != null) { // Yeah without this the loop just threw a nullpointerexception.
				writer.println(ngrams[i].getNgram() + ",     " + ngrams[i].getCount()); // I wanted to make the space relative to ngram size.
			}																			// I couldn't. Oh well!
		}
	}
	
	void readMyFile(File input, int n) throws EmptyFileException { //Slightly long-winded, but considering my progress in making separate methods...
		try {	
			Scanner scanner = new Scanner(input);
			PrintStream writer = new PrintStream("ngram-output-of-" + input.getName()); // Quite pleased with this little touch!

			if (scanner.hasNextLine() == false) {
				scanner.close();
				writer.close();
				throw new EmptyFileException(); // Dealing with empty files. Requisite catch statement below.
			}

			while (scanner.hasNextLine()) {
				String contents = scanner.nextLine();
				String delims = "[\\s]"; // Using space as the delimiter. Didn't bother with the rest of punctuation characters in the end.
				String[] a = contents.split(delims);
				for (int i=0; i<a.length; i++) { 
					if(a[i].length()>0) {
						analyseWord(cleanWord(a[i]), n); // The crucial line of code. This is where all the real action takes place!
					}
				} 
			}
			sortNgrams(); // Sorting the ngram array once the scanner's done, outputting a report, and closing the scanner.
			outputReport(writer, n);
			scanner.close();
		} 

		catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
			System.out.println("Please scan in a new file.");
			Thread.currentThread().getStackTrace();
		}														// Some basic catch statements to deal with major fails-I mean, errors.

		catch (EmptyFileException e) {
			System.out.println("The input file contains: " + e.getMessage());
			System.out.println("Please scan in a new file.");
			Thread.currentThread().getStackTrace();
		}
	}

	public static void main(String[] args) throws EmptyFileException { // Weird seeing a short main method. I'm still amazed at this.
		BigramProcessorFINAL processor = new BigramProcessorFINAL();
		File file = new File("Works of Edgar Allan Poe.txt");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please input n (a number from 1 upwards) for the n-gram calculator (n-grams of characters, mind), and then press enter.");
		String number = scanner.nextLine(); // Handily making the program interactive - you can choose n! You have to manually input the array
		scanner.close();					// size, though.
		int n = Integer.parseInt(number);	// Parsing the input into an integer.
		processor.readMyFile(file, n);
	}

}