
public class NgramInfo {

	private String ngram;
	private int count = 0;

	public String getNgram() {
		return ngram;
	}

	public void setNgram(String ngram) {
		this.ngram = ngram;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	public int increment() {
		count = count + 1;
		return count;
	}
	
}
