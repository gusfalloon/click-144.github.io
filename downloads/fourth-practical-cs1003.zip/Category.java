
public class Category {

	private String category;
	private int count = 0;
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	public int increment() {
		count = count + 1;
		return count;
	}

}
