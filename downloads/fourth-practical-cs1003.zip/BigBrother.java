import java.io.*;
import java.net.*;
import java.util.Scanner;

import javax.json.*;
import javax.json.stream.JsonParsingException;

public class BigBrother { //Thought this would be a good and completely PC name to choose! Nothing to see here officer!

	//Setting up parameters to pass into the program. 
	//Also constructing a static Category array (size not yet determined).
	private static String neighbourhoodsAndLocationString = "http://data.police.uk/api/";	 
	private static final int HTTP_OK = 200;
	private static final int noOfNeighbourhoods = 2;
	private static final int noOfCrimes = 3;
	private static String forcesString = "http://data.police.uk/api/forces"; 				 
	private static String categoriesString = "http://data.police.uk/api/crime-categories?date=2015-01";
	private static String crimeLocationString = "http://data.police.uk/api/crimes-street/all-crime?lat=";
	private static String googleString1 = "https://maps.googleapis.com/maps/api/staticmap?center=";
	private static String googleString2 = "&zoom=10&size=600x600&markers=color:blue%7C";
	static Category[] categories;
	private static Scanner scanner;

	//Don't tell me you didn't find this amusing. You'd be lying.
	private static String message1 =  " ____  _         ____            _   _                 _                     _       _     _                                       ";
	private static String message2 =  "| __ )(_) __ _  | __ ) _ __ ___ | |_| |__   ___ _ __  (_)___  __      ____ _| |_ ___| |__ (_)_ __   __ _   _   _  ___  _   _      ";
	private static String message3 =  "|  _ \\|" + " |/ _` | |  _ \\| '__/ _ \\| __| '_ \\ / _ \\ '__| | / __| \\ \\ /\\ / / _` | __/ __| '_ \\| | '_ \\ / _` | | | | |/ _ \\| | | |     ";
	private static String message4 =  "| |_) | | (_| | | |_) | | | (_) | |_| | | |  __/ |    | \\__ \\  \\ V  V / (_| | || (__| | | | | | | | (_| | | |_| | (_) | |_| |_ _ _ ";
	private static String message5 =  "|____/|_|\\__, | |____/|_|  \\___/ \\__|_| |_|\\___|_|    |_|___/   \\_/\\_/ \\__,_|\\__\\___|_| |_|_|_| |_|\\__, |  \\__, |\\___/ \\__,_(_|_|_)";
	private static String message6 =  "         |___/                                                                                     |___/   |___/                   ";
	private static String message = message1 + "\n" + message2 + "\n" + message3 + "\n" + message4 + "\n" + message5 + "\n" + message6 + "\n";

	//Counting the no. of categories and forces by
	//passing the result of the makeRESTCall method as a parameter.
	public static void main(String[] args) {
		System.out.println(message);
		try {		
			URL categoriesURL = new URL(categoriesString);
			int numberOfCategories = numberOfCrimeCategories(categoriesString, categoriesURL);
			URL forces = new URL(forcesString); //Setting up the number of categories and creating the forces URL
			userInterface(forces);			     		  
			scanner = new Scanner(System.in);				  
			System.out.print("Please enter the force that you are concerned with: ");
			String searchString = scanner.nextLine();
			while (searchString.isEmpty() || searchString.equals(" ")) {
				System.out.println("Nuh-uh. Try again."); //Dealing with erroneous input
				searchString = scanner.nextLine();
			}
			System.out.println();
			System.out.println("Now the date - the month that you are interested in. "
					+ "\nTake care to enter this in the following format (YYYY-MM): ");
			String date = scanner.nextLine();
			while (searchString.isEmpty() || searchString.equals(" ")) {
				System.out.println("Nuh-uh. Try again."); //Quite hard to defend against poor input here :(
				date = scanner.nextLine();
			}
			System.out.println();
			System.out.println("Search string: " + searchString);
			System.out.println("Date: " + date);
			whichForce(searchString, forces, date, numberOfCategories);
		} 
		catch (MalformedURLException e) {
			System.out.println("Invalid URL: " + e.getMessage());
			System.out.println("Please enter a valid URL."); //Dealing with a malformed URL request.
			Thread.currentThread().getStackTrace();
		} 
	}

	//The first of two user interfaces. This one is for the police force.
	public static void userInterface(URL forces) {
		JsonArray array = null;
		try {
			JsonReader jsonReader = Json.createReader(new StringReader(makeRESTCall(forces)));
			array = jsonReader.readArray(); //Making a query to the police data and retrieving all police forces listed
			for (int i = 0; i < array.size(); i++) {
				JsonObject policeForce = array.getJsonObject(i);
				System.out.printf("%10s %n", policeForce.getString("name")); //Formatting the returned strings
				if (i % 2 != 0)
					System.out.println(); //Keeping things tidy!
			}
			jsonReader.close();
		}
		catch (MalformedURLException e) {
			System.out.println("Invalid URL: " + e.getMessage());
			System.out.println("Please enter a valid URL.");
			Thread.currentThread().getStackTrace();
		} 
		catch (IOException e) {
			System.out.println("Invalid input: " + e.getMessage());
			System.out.println("Please enter valid input.");
			Thread.currentThread().getStackTrace();
		}
	}
	
	//The exact same logic as above, only this time for the neighbourhoods of the force requested.
	//No, I don't like breaking the DRY principle either. I did try to avoid this, but nay luck.
	public static void userInterface2(URL neighbourhoods) {
		JsonArray array = null;
		try {
			JsonReader jsonReader = Json.createReader(new StringReader(makeRESTCall(neighbourhoods)));
			array = jsonReader.readArray();
			for (int i = 0; i < array.size(); i++) {
				JsonObject neighbourhood = array.getJsonObject(i);
				System.out.printf("%3s %n", neighbourhood.getString("name"));
				if (i % 2 != 0)
					System.out.println();
			}
			jsonReader.close();
			System.out.println();
		}
		catch (MalformedURLException e) {
			System.out.println("Invalid URL: " + e.getMessage());
			System.out.println("Please enter a valid URL.");
			Thread.currentThread().getStackTrace();
		} 
		catch (IOException e) {
			System.out.println("Invalid input: " + e.getMessage());
			System.out.println("Please enter valid input.");
			Thread.currentThread().getStackTrace();
		}
	}

	//Finding the number of categories of crime for that given month. The result will then be passed through most
	//methods until it reaches the point where a Categories array is initialised.
	public static int numberOfCrimeCategories(String urlString, URL categoriesURL) {
		JsonArray array = null;
		try {			
			JsonReader jsonReader = Json.createReader(new StringReader(makeRESTCall(categoriesURL)));			
			array = jsonReader.readArray(); //Probably one of the nicer methods in terms of size...
			jsonReader.close();
		}
		catch (JsonParsingException e) { //Unlikely to happen unless the police change to something other than JSON...
			System.out.println("Something went wrong with the JSON-parsing process: " + e.getMessage());
			System.out.println("Please try again, or check that the source URL is valid.");
			Thread.currentThread().getStackTrace();
		} catch (IOException e) {
			System.out.println("Invalid input: " + e.getMessage());
			System.out.println("Please enter valid input.");
			Thread.currentThread().getStackTrace();
		}
		return array.size();
	}

	//Looking for a force in the array that matches the search string
	public static void whichForce(String searchString, URL forces, String date, int numberOfCategories) {
		JsonObject force = null;
		JsonArray array = null;
		try {
			searchString = searchString.toLowerCase();
			JsonReader jsonReader = Json.createReader(new StringReader(makeRESTCall(forces)));
			array = jsonReader.readArray();
			for (int i = 0; i < array.size(); i++) {
				JsonObject policeForce = array.getJsonObject(i);
				if (policeForce.getString("name").toLowerCase().contains(searchString)) { //One flaw - it can't guarantee a good result
					force = policeForce;												  //when several things contain the same string...
					System.out.println("Crime statistics for force: " + force.getString("name")); //like 'town', or even 'a'
					System.out.println();
					break; //When the program is this long, any efficiency is welcomed.
				}
			}
			getCounty(force, date, numberOfCategories);		
			jsonReader.close();
		}
		catch (MalformedURLException e) {
			System.out.println("Invalid URL: " + e.getMessage());
			System.out.println("Please enter a valid URL.");
			Thread.currentThread().getStackTrace();
		} 
		catch (IOException e) {
			System.out.println("Invalid input: " + e.getMessage());
			System.out.println("Please enter valid input.");
			Thread.currentThread().getStackTrace();
		}
	}

	//Me trying to be interactive! Second interface being used, with a fairly nice way of dealing with
	//'Just give me some damn data already'.
	public static void getCounty(JsonObject force, String date, int numberOfCategories) {
		JsonObject neighbourhood;
		JsonArray array = null;
		try {	
			String id = force.getString("id");
			String neighbourhoodsString = neighbourhoodsAndLocationString + id + "/neighbourhoods";
			URL neighbourhoods = new URL(neighbourhoodsString);
			userInterface2(neighbourhoods);
			System.out.println("Would you like the standard output or to choose your own neighbourhood? "
					+ "\nIf you would like to pick a neighbourhood, please enter one listed above. If not, simply press enter.");
			String answer = scanner.nextLine();
			if (answer.isEmpty() || answer.equals(" ")) { //The true power of conditionals is amazing...
				scanner.close();
				JsonReader jsonReader = Json.createReader(new StringReader(makeRESTCall(neighbourhoods)));
				array = jsonReader.readArray();
				for (int i = 0; i < array.size(); i++) {
					neighbourhood = array.getJsonObject(i);
					System.out.println(neighbourhood.getString("name"));
					getDistrict(neighbourhood, force, id, date, numberOfCategories);
					if (i == noOfNeighbourhoods)
						break; 
				}//This is where the real genius tells. Both a map AND a html file provided! Very proud of this.
				 //Frightfully long and inefficient though :/
				System.out.println("A map of the district specified is in the following link below. "
						+ "Simply copy and paste onto your browser. Please note that this may not include every neighbourhood.");
				googleMap(force);
				chart(force, date, numberOfCategories);
				System.out.println("\nYou should also find that there's a HTML file containing a chart of the data. Enjoy!");
			}
			else {
				scanner.close();
				answer = answer.toLowerCase();
				JsonReader jsonReader = Json.createReader(new StringReader(makeRESTCall(neighbourhoods)));
				array = jsonReader.readArray();
				for (int i = 0; i < array.size(); i++) {
					neighbourhood = array.getJsonObject(i);
					if (neighbourhood.getString("name").toLowerCase().contains(answer)) {
						System.out.println(neighbourhood.getString("name"));
						getDistrict(neighbourhood, force, id, date, numberOfCategories);
						break;
					}
				}
				System.out.println("A map of the district specified is in the following link below. "
						+ "Simply copy and paste onto your browser.");
				googleMap(force);
				chart(force, date, numberOfCategories);
				System.out.println("\nYou should also find that there's a HTML file containing a chart of the data. Enjoy!");
			}
		}
		catch (MalformedURLException e) {
			System.out.println("Invalid URL: " + e.getMessage());
			System.out.println("Please enter a valid URL.");
			Thread.currentThread().getStackTrace();
		}
		catch (IOException e) {
			System.out.println("Invalid input: " + e.getMessage());
			System.out.println("Please enter valid input.");
			Thread.currentThread().getStackTrace();
		}
		catch (NullPointerException e) {
			System.out.println("I don't believe you entered a valid police force... Your query returned: " + e.getMessage());
			System.out.println("Please enter valid input."); //Trying to deal with invalid inputs that return null
			Thread.currentThread().getStackTrace();
		}
	}

	//The infamous Delayor of All Things. Dun dun dun!
	public static void chart(JsonObject force, String date, int numberOfCategories) {
		JsonObject neighbourhood = null;
		JsonArray array = null; //Wayyyyyy too long but it does work. Takes a while to load this, worryingly...
		int numberOfCrimes = 0;
		String output = "";
		try {
			String id = force.getString("id");
			String neighbourhoodsString = neighbourhoodsAndLocationString + id + "/neighbourhoods";
			URL neighbourhoods = new URL(neighbourhoodsString);
			JsonReader jsonReader = Json.createReader(new StringReader(makeRESTCall(neighbourhoods)));
			array = jsonReader.readArray();
			String[] string = new String[array.size()];
			for (int i = 0; i < array.size(); i++) {
				neighbourhood = array.getJsonObject(i);	
				string[i] = neighbourhood.getString("name");
				string[i] = "['" + string[i] + "', "; //Sorting out the HTML code
				String neighbourhoodID = "/" + neighbourhood.getString("id");
				String locationString = neighbourhoodsAndLocationString + id + neighbourhoodID;
				URL locationURL = new URL(locationString);
				jsonReader = Json.createReader(new StringReader(makeRESTCall(locationURL)));
				JsonObject location = jsonReader.readObject();
				JsonObject coordinates = location.getJsonObject("centre");
				String latitude = coordinates.getString("latitude");
				String longitude = coordinates.getString("longitude");
				
				//This is really what the program has already done, but I couldn't figure out
				//how to get more efficient :(
				
				latitude = latitude + "&lng="; 
				longitude = longitude + "&date=";
				String eachCrimeLocationString = crimeLocationString + latitude + longitude + date;
				URL crimeLocationURL = new URL(eachCrimeLocationString);
				jsonReader = Json.createReader(new StringReader(makeRESTCall(crimeLocationURL)));
				JsonArray array1 = jsonReader.readArray();
				for (int j = 0; j < array1.size(); j++) {
					numberOfCrimes++; //Getting the sum as mentionned in the total number of crimes in the console.
				}
				string[i] = string[i] + numberOfCrimes + "],\n";
				output = output.concat(string[i]); //Was quite pleased with my solution to this actually.
				numberOfCrimes = 0;
				if(i == 100)
					break; //Google doesn't seem to like too many entries, which is fair enough. 100 is PLENTY, anyway.
			}
			File outputFile = new File("index.html");
			PrintWriter writer = new PrintWriter(outputFile);
			writer.println("<!DOCTYPE html>\n"
						  +"<html>\n"
						  + "<head>\n"
						   + "<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>\n"
						   + "<script type=\"text/javascript\">\n"
						   + "google.load(\"visualization\", \"1\", {packages:[\"corechart\"]});\n"
						   + "google.setOnLoadCallback(drawChart);\n"
						   + "function drawChart() {\n"
						   + "var data = google.visualization.arrayToDataTable([\n"//The surrounding HTML code
						   + "['Neighbourhood', 'Number of crimes'],\n" 
						   + output + "]);\n" //And there hiding in the corner is the output from this program! 
						   + "var options = {\n"
						   + "title: 'Number of crimes per neighbourhood',\n"
						   + "legend: { position: 'none' },\n"
						   + "};\n"
						   + "var chart = new google.visualization.Histogram(document.getElementById('chart_div'));\n"
						   + "chart.draw(data, options);\n"
					  	   + "}\n"
					 	   + "</script>\n"
						  + "</head>\n"
						  + "<body>\n"
						   + "<div id=\"chart_div\" style=\"width: 900px; height: 500px;\"></div>\n"
						  + "</body>\n"
						 + "</html>");
			writer.close();
		}
		catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
			System.out.println("Please try again.");
			Thread.currentThread().getStackTrace();
		} 
		catch (MalformedURLException e) {
			System.out.println("Invalid URL: " + e.getMessage());
			System.out.println("Please enter a valid URL.");
			Thread.currentThread().getStackTrace();
		} 
		catch (IOException e) {
			System.out.println("Invalid input: " + e.getMessage());
			System.out.println("Please enter valid input.");
			Thread.currentThread().getStackTrace();
		}
	}

	//I wonder what this does...
	public static void googleMap(JsonObject force) {
		JsonObject neighbourhood = null;
		JsonArray array = null;
		float averageLat = 0;
		float averageLong = 0;
		String googleURL = null;
		try {
			String id = force.getString("id");
			String neighbourhoodsString = neighbourhoodsAndLocationString + id + "/neighbourhoods";
			URL neighbourhoods = new URL(neighbourhoodsString);
			JsonReader jsonReader = Json.createReader(new StringReader(makeRESTCall(neighbourhoods)));
			array = jsonReader.readArray();
			GoogleMapInfo[] mapInfo = new GoogleMapInfo[array.size()];
			for (int i = 0; i < array.size(); i++) {
				neighbourhood = array.getJsonObject(i);	
				String neighbourhoodID = "/" + neighbourhood.getString("id");
				String locationString = neighbourhoodsAndLocationString + id + neighbourhoodID;
				URL locationURL = new URL(locationString);
				JsonReader secondJsonReader = Json.createReader(new StringReader(makeRESTCall(locationURL)));
				JsonObject location = secondJsonReader.readObject();
				JsonObject coordinates = location.getJsonObject("centre");
				String latitude = coordinates.getString("latitude");
				String longitude = coordinates.getString("longitude");
				mapInfo[i] = new GoogleMapInfo();
				mapInfo[i].addCoordinates(latitude, longitude);
				averageLat += mapInfo[i].getLat();   
				//Quite clever this. In absence of central coordinates for a neighbourhood, I took the averages and made
				//that the centre of the map generated. Always creates a map with decent positioning and makes good use
				//of the size of the map.
				averageLong += mapInfo[i].getLong();
			}
			averageLat = averageLat / array.size();
			averageLong = averageLong / array.size();
			googleURL = googleString1 + averageLat + "," + averageLong + googleString2;
			for (int i = 0; i < array.size(); i++) {
				googleURL = googleURL.concat(mapInfo[i].getLatString() + "," + mapInfo[i].getLongString() + "%7C");
				if (i == 50)
					break; //Can't have too many entries, can we?
			}
			System.out.println(googleURL);
		}	
		catch (MalformedURLException e) {
			System.out.println("Invalid URL: " + e.getMessage());
			System.out.println("Please enter a valid URL.");
			Thread.currentThread().getStackTrace();
		}
		catch (IOException e) {
			System.out.println("Invalid input: " + e.getMessage());
			System.out.println("Please enter valid input.");
			Thread.currentThread().getStackTrace();
		}

	}

	//Fairly obvious...
	public static void getDistrict(JsonObject neighbourhood, JsonObject force, String id, String date, int numberOfCategories) {
		try {
			String neighbourhoodID = "/" + neighbourhood.getString("id");
			String locationString = neighbourhoodsAndLocationString + id + neighbourhoodID;
			URL locationURL = new URL(locationString);
			JsonReader jsonReader = Json.createReader(new StringReader(makeRESTCall(locationURL)));
			JsonObject location = jsonReader.readObject();
			JsonObject coordinates = location.getJsonObject("centre");
			String latitude = coordinates.getString("latitude"); //Retrieving the coordinates of the neighbourhood
			String longitude = coordinates.getString("longitude");
			crimeLocation(neighbourhood, latitude, longitude, date, numberOfCategories);
		}
		catch (MalformedURLException e) {
			System.out.println("Invalid URL: " + e.getMessage());
			System.out.println("Please enter a valid URL.");
			Thread.currentThread().getStackTrace();
		}
		catch (IOException e) {
			System.out.println("Invalid input: " + e.getMessage());
			System.out.println("Please enter valid input.");
			Thread.currentThread().getStackTrace();
		}
	}

	//Looking through the crimes array and retrieving the location of EACH crime. No wonder this program lags sometimes...
	public static void crimeLocation(JsonObject neighbourhood, String latitude, String longitude, String date, int numberOfCategories) {
		try {
			latitude = latitude + "&lng=";
			longitude = longitude + "&date=";
			String eachCrimeLocationString = crimeLocationString + latitude + longitude + date;
			URL crimeLocationURL = new URL(eachCrimeLocationString);
			JsonReader jsonReader = Json.createReader(new StringReader(makeRESTCall(crimeLocationURL)));
			JsonArray array = jsonReader.readArray();
			categories = new Category[numberOfCategories]; //Finally initialising the categories array!
			for (int i = 0; i < array.size(); i++) {
				JsonObject neighbourhoodCrimeDetails = array.getJsonObject(i);
				String crimeCategory = neighbourhoodCrimeDetails.getString("category");
				if (crimeCategory != null) {
					recordCategory(crimeCategory);
				}
				else {
					continue; //Keep things moving..
				}
				sortDetails(); //Ah, I remember this method...		
			}
			printStats(latitude, longitude);
		}
		catch (MalformedURLException e) {
			System.out.println("Invalid URL: " + e.getMessage());
			System.out.println("Please enter a valid URL.");
			Thread.currentThread().getStackTrace();
		}
		catch (IOException e) {
			System.out.println("Invalid input: " + e.getMessage());
			System.out.println("Please enter valid input.");
			Thread.currentThread().getStackTrace();
		}
	}

	//A bit of number-crunching and voila!
	public static void printStats(String latitude, String longitude) {
		float sum = 0;
		float percentage = 0;
		for (int i = 0; i < categories.length; i++) {
			if (categories[i] != null)
				sum += categories[i].getCount(); 
		}
		int finalSum = Math.round(sum); //Getting the total number of crimes in that area
		System.out.println("The total number of crimes at this neighbourhood is" 
				+ ": " + finalSum);
		for (int j = 0; j < noOfCrimes; j++) {
			if (categories[j] != null) { //A null check
				percentage = (categories[j].getCount() / sum) * 100;
				int finalPercentage = Math.round(percentage);
				System.out.println(categories[j].getCategory() + ": " + finalPercentage + "%");
			}
		}
		System.out.println();
	}	

	//Familiar ground - recording a new category, and/or incrementing one.
	public static void recordCategory(String crimeCategory) {
		int position = findCategory(crimeCategory);
		if (categories[position] == null) {
			categories[position] = new Category();
			categories[position].setCategory(crimeCategory); // Initialising a category and incrementing the count if the category is new.
			categories[position].increment();			
		}
		else {
			categories[position].increment(); // Otherwise, only the count changes.
		}
	}

	//Searching for a category in case it's already been noted down.
	public static int findCategory(String crimeCategory) {
		int position = 0;
		for (int i = 0; i < categories.length; i++) {
			if(categories[i] == null) { // In the case where the program encounters null
				position = i;
				break;
			}	// In the case where the program encounters a non-null n-gram that isn't equivalent to the one it's looking for.
			else if ((categories[i].getCategory() != null) && !(categories[i].getCategory().equals(crimeCategory))) { 
				continue;																		
			}																					
			else { // The correct ngram is found, and the loop breaks (so it doesn't waste time looking through the entire array).
				position = i; 
				break;
			}
		}
		return position;
	}

	//This and the next four methods are all standardised. Credits due to: someone@st-andrews.ac.uk.way.too.many.damn.characters!!!
	public static void sortDetails() {
		for (int i = 0; i < categories.length; i++) {
			for (int j = 0; j < categories.length - i - 1; j++) {
				if (outOfOrder(j)) swap(j);
			}
		}
	}

	public static boolean outOfOrder(int j) {

		// We want to sort with highest count first, so two adjacent elements are out of order
		// if the count of the first one is less than that of the second one.
		return categories[j] != null && categories[j+1] != null && categories[j].getCount() < categories[j+1].getCount();
	}

	public static void swap(int j) {
		Category temp = categories[j];
		categories[j] = categories[j+1];
		categories[j+1] = temp;
	}

	public static String makeRESTCall(URL url) throws IOException {
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		StringBuilder output = new StringBuilder();

		try (BufferedReader br = new BufferedReader(new InputStreamReader((connection.getInputStream())));) {
			int response_code = connection.getResponseCode();
			if (response_code != HTTP_OK) { 
				throw new IOException("Error code : " + response_code); 
			}
			String line;
			while ((line = br.readLine()) != null) {
				output.append(line);
			}
		}
		finally {
			connection.disconnect();
		}
		return output.toString();
	}	
}

//Yes, this is horrifically long. I apologise. Perhaps I will buy you chocolate to overlook this *minute* issue.