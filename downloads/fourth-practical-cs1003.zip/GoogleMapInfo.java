
public class GoogleMapInfo {

	private float lat;
	private float longi;
	
	public float getLat() {
		return lat;
	}
	public float getLong() {
		return longi;
	}
	public String getLatString() {
		String latString = String.valueOf(lat);
		return latString;
	}
	public String getLongString() {
		String longString = String.valueOf(longi);
		return longString;
	}
	public void addCoordinates(String latitude, String longitude) {
		float lat = Float.parseFloat(latitude);
		float longi = Float.parseFloat(longitude);
		this.lat = lat;
		this.longi = longi;
	}

}
