
public class Negation {

	public static final String symbol = "~";
	private static final int ranking = 1;
	private static final int[] truthTable = {1, 
											 0};
	public static int[] getTruthtable() {
		return truthTable;
	}
	
}
