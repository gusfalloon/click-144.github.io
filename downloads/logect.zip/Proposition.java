
public class Proposition {

	private Character letter;
	private int[] truthTable;

	public Proposition(Character letter) {
		super();
		this.letter = letter;
	}

	public Character getLetter() {
		return letter;
	}

	public void setLetter(Character letter) {
		this.letter = letter;
	}

	public int[] getTruthTable() {
		return truthTable;
	}

	public void setTruthTable(int[] truthTable) {
		this.truthTable = truthTable;
	}
	
}
