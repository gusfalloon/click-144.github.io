
public class Conjunction {
	
	public static final String symbol = "&";
	private static final int ranking = 2;
	private static final int[] truthTable = {1, 
											 0, 
											 0, 
											 0};
	
	public static int[] getTruthtable() {
		return truthTable;
	}
	
}
