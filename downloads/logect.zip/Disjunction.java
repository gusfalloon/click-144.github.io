
public class Disjunction {

	public static final String symbol = "V";
	private static final int ranking = 2;
	private static final int[] truthTable = {1, 
											 1, 
											 1, 
											 0};

	public static int[] getTruthtable() {
		return truthTable;
	}

}
