
public class Biconditional {

	public static final String symbol = "<->";
	private static final int ranking = 4;
	private static final int[] truthTable = {1, 
											 0, 
											 0, 
											 1};

	public static int[] getTruthtable() {
		return truthTable;
	}


}