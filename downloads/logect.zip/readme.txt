
Readme.txt file for: Logect



+*********************************************************************************************************+
Context:
+*********************************************************************************************************+

* Propositional Logic is the study and formalisation of arguments. It uses various methods to determine
  whether or not an arbitrary string of logical connectives and propositions (hence the Propositional in 
  Propositional Logic) is a valid argument.

* Whilst I took great enjoyment in learning about Logic in St Andrews, I personally felt disappointed in
  how we were taught. I didn’t feel like I could really test my knowledge very well against something (or
  indeed, someone). 

+*********************************************************************************************************+
Purpose and aims:
+*********************************************************************************************************+

* So, my Logic-Project (abbreviated to Logect) is to write a Java program that:
	
	+ Determines whether or not an arbitrary input is a wff (essentially a logical statement) that 
	  follows the syntactic and grammatical rules of PL.

	+ Whether or not the wff in question is a tautology, a contradiction, or a contingent statement.

	+ ~Possibly~ be able to give a truth-table for a wff.

* Hopefully, to be used as a standard of language. This is because, during my various searches across the
  web, there appeared to be many different ways of saying exactly the same connectives. Whilst variety is
  not to be criticised per se, it is a) unnecessary and b) potentially confusing. This writer would 
  suggest that a single means of expressing the connectives in a form that foregoes the need for special
  characters would be ideal for all parties concerned.

* Lastly, to provide a user-friendly introduction to the field. Seeing as I am a student who has just 
  passed a Logic module, I believe I am in a unique position to help explain to fellow budding logicians
  how exactly these strange symbols all fit together.

+*********************************************************************************************************+
Design and implementation:
+*********************************************************************************************************+

* I have decided to use Java for the simple reason that it is the only language I have learned so far
  in my studies. Although other languages could be more efficient at the task at hand, it is still 
  good practice and a good way to enforce the object-orientated approach.

* It was a very challenging decision to work out how best to start. Some questions that needed to be 
  answered involved:

	1 How many arguments/propositions do I allow? Do I look for a particular letter?
	2 How does one verify that an arbitrary input is a wff?
	3 How would one go about proving that said input is a wff? From left to right? Or smallest-wff
	  first? Maybe largest?

I will answer each of these from first to last:

1: I decided to follow suit on the (relatively crude) examples I found on the internet and used a
   maximum of 5 arguments, from P in alphabetical order to U. This is because the majority of arguments
   don’t need any more propositions than that, and also because I decided to use the letter ’V’ for the
   OR symbol. Given that P is the letter I was weaned on, and because it’s the first letter in 
   ‘Proposition’, I decided to make P the default first letter of any argument.

   Result: maximum of 5 letters, and starting from P (meaning that P must be present and every other
   character must be lexicographically between P and U inclusive).

2: Anyone who has learnt PL will know that the following isn’t even a formula:
	
	P & ‘( ->
	  <->

   We can’t even tell which character is the second, so that’s no good. The following IS a formula:

	P Q & (->)

   Even though it isn’t actually a Well-Formed Formula (hence ‘wff’). The following is a wff:

	(P & Q) -> R

   Which expresses that if P and Q are both true, then R will be true.

   Result: the input must be a single-line string containing ONLY connectives and propositions. It must
   also be that these connectives and propositions are arranged in a particular order.

3: We need a program that determines that an arbitrary input is a wff in an effective and efficient
   manner. Given the way we evaluate wffs in a truth-table, and to give the program a flexibility for
   future improvement, we will evaluate inputs on a ‘smallest—wff-first’ basis. This will mean a single
   sweep of the input to determine the ‘ranking’ of each wff (if any), and then evaluate them from
   smallest to largest.

   Result: *we will deal with inputs in a two-stage process. First, we will figure out the order of the
   wffs that we are going to compute. Then, we compute them.* If at any stage the program rejects the 
   input, we will return a false value (so the checks are going to be boolean methods).

   NB: If the above starred statement seems like a slightly circular conclusion, a wff always contains a
   letter. Given this, and the bracket conventions in PL, we can work out the order in which we deal
   with wffs.






















