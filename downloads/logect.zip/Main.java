import java.util.*;

public class Main {

	private static final int maxNumberOfPropositions = 5;
	private static Proposition[] proposition = new Proposition[maxNumberOfPropositions];
	private static String message = "Greetings! Please enter a wff of your choice and press enter. Alternatively, if you \nwould like"
			+ " to enter an argument, please enter your premises, separated by a comma. \n\n"
			+ "Symbols should be entered as shown (otherwise the program will say the wff is invalid): \n"
			+ "* Not-___: ~___\n"
			+ "* ___ and ___: ___&___\n"
			+ "* ___ or ___: ___v___\n"
			+ "* If___ then ___: ___->___\n"
			+ "* ___ if and only if (iff) ___: ___<->___\n\n"
			+ "Please take care not to use 'V' as a proposition (that letter is used for the OR symbol).\n"
			+ "Furthermore, do not distinguish your propositions by case - please use another letter.\n"
			+ "Regarding proposition letters, please start from P onwards (excluding V, obviously).\n"
			+ "If you would like to exit the program, please enter 'Quit', case-insensitive.\n";

	public static void checkInput(String line) {
		line = line.trim();
		line = line.toUpperCase();
		line = line.replace(" ", "");
		boolean crudeCheck = crudeBracketCheck(line);
		if (crudeCheck == false)
			System.out.println("Not a wff - either: \n*Incorrect number of brackets/"
					+ "more of one bracket than the other, or\n"
					+ "*There are no propositions in the input.");
		else {
			boolean deepCheck = deepBracketCheck(line);
			if (deepCheck == false)
				System.out.println("Not a wff - bracketing convention is not met by the input.");
			else {
				boolean propositionCheck = sortPropositions(line);
				boolean isAWff = finalCheck(line);
				if ((propositionCheck == false || isAWff == false))
					System.out.println("Not a wff - input does not meet syntactic requirements.");
				else
					System.out.println(line + " is a wff!");
			}
		}
	}

	private static boolean crudeBracketCheck(String line) {
		boolean hasPropositions = false;
		boolean crudeCheck = false;
		int noOfClosingParentheses = 0;
		int noOfOpeningParentheses = 0;
		for (int i = 0; i < line.length(); i++) {
			Character c = line.charAt(i);
			if (c == '(')
				noOfOpeningParentheses++;
			else if (c == ')')
				noOfClosingParentheses++;
			else if (Character.isLetter(c))
				hasPropositions = true;
		}
		if ((noOfOpeningParentheses == noOfClosingParentheses) && hasPropositions == true)
			crudeCheck = true;
		return crudeCheck;
	}

	private static boolean deepBracketCheck(String line) {
		boolean bracketConvention = false;
		int countOfOtherBrackets = 0;
		if (!(line.contains("(") || line.contains(")"))) // 
			bracketConvention = true;
		else {
			for (int i = 0; i < line.length() - 1; i++) {
				Character c = line.charAt(i);
				if (c == '(') {
					for (int j = i + 1; j < line.length(); j++) {
						Character d = line.charAt(j);
						if (d == ')' && j == i + 1) {
							bracketConvention = false;
							break;
						}
						if (d == '(')
							countOfOtherBrackets++;
						else if ((d == ')') && countOfOtherBrackets != 0) {
							countOfOtherBrackets--;
						}
						else if ((d == ')') && countOfOtherBrackets == 0) {
							bracketConvention = true;
							break;
						}
					}
				}
			}
		}
		return bracketConvention;
	}

	private static boolean sortPropositions(String line) {
		boolean propositionCheck = false;
		int numberOfPropositions = 0;
		for (int i = 0; i < line.length(); i++) {
			if (i > 0 && i < line.length()) {
				Character c = line.charAt(i);
				Character before = line.charAt(i - 1);
				if ((Character.isLetter(c) && Character.isLetter(before))) {
					return propositionCheck;
				}
			}
		}
		for (int i = 0; i < line.length(); i++) {
			Character c = line.charAt(i);
			if (Character.isLetter(c) && ((c.toString()).compareTo("P") >= 0) && !(c.equals('V'))) {
				if (!(checkForRepeatedLetter(c))) {
					proposition[numberOfPropositions] = new Proposition(c);
					numberOfPropositions++;
				}
			}
			else if (Character.isDigit(c)) {
				return propositionCheck;
			}
		}
		sortPropositionArray();
		for (int i = 0; i < maxNumberOfPropositions; i++) {
			if (proposition[i] != null)
				System.out.print(proposition[i].getLetter() + " ");
			else
				System.out.print("[ ]");
		}
		System.out.println();
		propositionCheck = true;
		return propositionCheck;
	}

	private static boolean checkForRepeatedLetter(Character c) {
		boolean repeat = false;
		for (int i = 0; i < maxNumberOfPropositions; i++) {
			if (proposition[i] != null && proposition[i].getLetter().equals(c)) {
				repeat = true;
				return repeat;
			}
		}
		return repeat;
	}

	private static void sortPropositionArray() {
		for (int i = 0; i < maxNumberOfPropositions; i++) {
			for (int j = 0; j < maxNumberOfPropositions - i - 1; j++) {
				if (outOfOrder(j)) swap(j);
			}
		}
	}

	private static boolean outOfOrder(int j) {

		// We want to sort with highest count first, so two adjacent elements are out of order
		// if the count of the first one is less than that of the second one.
		return proposition[j] != null && proposition[j+1] != null && proposition[j].getLetter() > proposition[j+1].getLetter();
	}

	private static void swap(int j) {

		Proposition temp = proposition[j];
		proposition[j] = proposition[j+1];
		proposition[j+1] = temp;
	}

	private static boolean finalCheck(String line) {
		int countOfOtherBrackets = 0;
		boolean isACompleteWff = false;
		for (int i = 0; i < line.length() - 1; i++) {
			Character c = line.charAt(i);
			if (c.equals('(')) {
				for (int j = i + 1; j < line.length(); j++) {
					Character d = line.charAt(j);
					if (d == '(')
						countOfOtherBrackets++;
					else if ((d == ')') && countOfOtherBrackets != 0) {
						countOfOtherBrackets--;
					}
					else if ((d == ')') && countOfOtherBrackets == 0) {
						analyseSection(line, i, j);
						break;
					}
				}
			}
		}
		return isACompleteWff;
	}
	
	private static boolean analyseSection(String line, int i, int j) {
		boolean isAWff = false;
		boolean validBiconditional = false;
		boolean validConditional = false;
		boolean validDisjunction = false;
		boolean validConjunction = false;
		boolean validNegation = false;
		line = line.substring(i + 1, j);
		System.out.println(line + " is the input");
		if (line.contains("<->"))
			validBiconditional = biconditionalMethod(line);
		else if (line.contains("->"))
			validConditional = conditionalMethod(line);
		else if (line.contains("V"))
			validDisjunction = disjunctionMethod(line);
		else if (line.contains("&"))
			validConjunction = conjunctionMethod(line);
		if (!(validBiconditional && validConditional && validDisjunction && validConjunction && validNegation))
			return isAWff;
		else
			isAWff = true;
		return isAWff;
	}

	private static boolean biconditionalMethod(String line) {
		return false;
	}
	
	private static boolean conditionalMethod(String line) {
		return false;
	}
	
	private static boolean disjunctionMethod(String line) {
		return false;
	}
	
	private static boolean conjunctionMethod(String line) {
		return false;
	}

	public static void main(String[] args) {
		System.out.println(message);
		Scanner scanner = new Scanner(System.in);
		String line = scanner.nextLine();
		while (line.isEmpty() || line.equals(" ") || line.equalsIgnoreCase("Quit")) {
			if (line.equalsIgnoreCase("QUIT"))
				System.exit(0);
			System.out.println("Please try again.");
			line = scanner.nextLine();
		}
		long startingTime = System.currentTimeMillis();
		checkInput(line);
		long timeTaken = System.currentTimeMillis() - startingTime;
		System.out.println("Time taken: " + timeTaken + " milliseconds.");
	}

}
