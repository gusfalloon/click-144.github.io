import java.io.*;
import java.lang.*;

public class W05Practical {
	public static void main(String [] args) {

	System.out.println("Please enter your weight in kilograms.");
	float weightKg = EasyIn.getFloat();
		if (weightKg<=0) {
			System.out.println("That is not a valid input - you're not that skinny! Please enter a decent answer next time!");
		}
		if (weightKg>=200) {
			System.out.println("That is not a valid input - you're not that fat! Please enter a decent answer next time!");
		}
		else {
			int weightRounded = java.lang.Math.round(weightKg);
			System.out.println("Thank you. Your weight is, when rounded, " + weightRounded + " kilograms.");
		

	double ounces = 35.27 * weightRounded;
	long ouncesRounded1 = java.lang.Math.round(ounces);
	int ouncesRounded = java.lang.Math.round(ouncesRounded1);

	System.out.println("Would you like your weight in ounces? Please answer 'Yes' or 'No'.");
	String answer = EasyIn.getString();
	if (answer.equals ("Yes")) {
			System.out.println("Your weight in ounces is: " + ouncesRounded + " ounces.");
		}
		else {
			System.out.println("Thank you.");
		}
	
	int pounds = ouncesRounded / 16;

	System.out.println("Would you like your weight in pounds? Please answer 'Yes' or 'No'.");
	String answer1 = EasyIn.getString();
	if (answer1.equals ("Yes")) {
			System.out.println("Your weight in pounds is: " + pounds + " pounds.");
		}
		else {
			System.out.println("Thank you.");
		}

	int stones = pounds / 14;

	System.out.println("Would you like your weight in stones? Please answer 'Yes' or 'No'.");
	String answer2 = EasyIn.getString();
	if (answer2.equals ("Yes")) {
			System.out.println("Your weight in stones is: " + stones + " stones.");
		}
		else {
			System.out.println("Thank you.");
		}
	} 
	}
}
