import java.io.*;
import java.lang.*;

public class W05Practical1 {
	public static void main(String [] args) {

	System.out.println("Please enter your weight in kilograms. Enter a number between 0 and 200 (not inclusive)."); 
																// Retrieving the weight in kgs (within reason). Note the program's courtesy in the process!
	float weightKg = EasyIn.getFloat();
	if (weightKg<=0) {
			System.out.println("That is not a valid input - you're not that skinny! Please enter a decent answer next time!");
		}
	if (weightKg>=200) {
			System.out.println("That is not a valid input - you're not that fat! Please enter a decent answer next time!");
		}
	else {
		int weightRounded = java.lang.Math.round(weightKg);
		System.out.println(" ");
		System.out.println("Thank you. Your weight is, when rounded, " + weightRounded + " kilograms.");
		
	double ounces1 = weightRounded * 35.27; // Slight technical issue here. I had to covert the kg weight into a double, then a long, and then an integer.
	long ounces2 = java.lang.Math.round(ounces1); // Computer kept throwing a fit otherwise. Wasn't able to work out why that was.
	int ounces = java.lang.Math.round(ounces2);

	int pounds = ounces / 16;
	int ouncesRemainder = (ounces) - (pounds * 16); // Now, the conversions. This took a while. Shan't say how close to the deadline (~ 100 milliseconds)...

	int stones = pounds / 14;
	int poundsRemainder = (pounds) - (stones * 14);

	System.out.println(" "); // Just a spaced line to make things a little more digestible. Note my ingenuity in applying it to all outputs as well :)
	System.out.println("Would you like your imperial weight? Please answer 'Yes' or 'No' exactly as presented.");
	String answer = EasyIn.getString();
	if (answer.equals("Yes")) {
	System.out.println(" ");
		if (stones != 0 && poundsRemainder % 14 != 0 && ouncesRemainder % 16 != 0) {
			System.out.println("Your imperial weight is: " + stones + " stones, " + poundsRemainder + " pounds, " + ouncesRemainder + " ounces.");
		}
		else if (stones != 0 && poundsRemainder % 14 != 0 && ouncesRemainder % 16 == 0) {
			System.out.println("Your imperial weight is: " + stones + " stones, " + poundsRemainder + " pounds.");
		}
		else if (stones != 0 && poundsRemainder % 14 == 0 && ouncesRemainder % 16 != 0) {
			System.out.println("Your imperial weight is: " + stones + " stones, " + ouncesRemainder + " ounces.");
		}
		else if (stones != 0 && poundsRemainder % 14 == 0 && ouncesRemainder % 16 == 0) {
			System.out.println("Your imperial weight is: " + stones + " stones."); // Some beautifully-crafted conditionals that output the converted weight.
		}   

// Thankfully I noticed this - what if you put 1kg? In other words, stones == 0. I corrected this issue and extended the conditional statements to allow for this.

		else if (stones == 0 && poundsRemainder % 14 != 0 && ouncesRemainder % 16 != 0) {
			System.out.println("Your imperial weight is: " + poundsRemainder + " pounds, " + ouncesRemainder + " ounces."); 
		}
		else if (stones == 0 && poundsRemainder % 14 != 0 && ouncesRemainder % 16 == 0) {
			System.out.println("Your imperial weight is: " + poundsRemainder + " pounds."); 
		}
		else if (stones == 0 && poundsRemainder % 14 == 0 && ouncesRemainder % 16 != 0) {
			System.out.println("Your imperial weight is: " + ouncesRemainder + " ounces."); 
		}
	else {
		System.out.println("Thank you."); // Might as well be polite. Rude to ask people about their weight anyway!
	}
}
}
}
}
