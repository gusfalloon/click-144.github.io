public class W07Practical {

	public static void main(String[] args) {
	
		Park countrypark = new Park();
		createDepartments("Facilities", "Events");

		department1.printDetails();
		department2.printDetails();
	
	}
}
