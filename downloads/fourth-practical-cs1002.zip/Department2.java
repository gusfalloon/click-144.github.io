
public class Department2 {
	private String name = "Facilities";
	public String head = "Mr Turver";
	public String secretary = "Mrs Turai-kiss";
	private double budget = 1000000;
	
	public int numberofF = 0;
	private String mostExpensiveF = " ";
	private String leastExpensiveF = " ";
	
		
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getHead() {
		return head;
	}
	
	public void setHead(String head) {
		this.head = head;
	}

	public String getSecretary() {
		return secretary;
	}
	
	public void setSecretary(String secretary) {
		this.secretary = secretary;
	}

	public double getBudget() {
		return budget;
	}
	
	public void setBudget(double budget) {
		this.budget = budget;
	}
	
	public void printDetails() {
		System.out.println(name + ":");
		System.out.println("Head: " + head);
		System.out.println("Secretary: " + secretary);
		System.out.println("Annual budget: " + "£" + budget);
		System.out.println(" ");
	}
	
	public double requestNewFacility(String facility, double cost) {
		double newBudget = budget - cost;
		if(cost > budget) {
			System.out.println("This facility is not within our budget constraint, we are sorry.");
			System.out.println("");
			newBudget = budget - 0;
		}
		else if(cost <= budget) {
			System.out.println("Thank you, this facility request has been granted.");
			System.out.println("");
			newBudget = budget - cost;
		}
		System.out.println("£" + newBudget);
		System.out.println("");
		budget = newBudget;
		return budget;
	}

	public int getNumberofF() {
		return numberofF;
	}

	public String getMostExpensiveF() {
		return mostExpensiveF;
	}

	public String getLeastExpensiveF() {
		return leastExpensiveF;
	}

	public void setNumberofF(int numberofF) {
		this.numberofF = numberofF;
	}

	public void setMostExpensiveF(String mostExpensiveF) {
		this.mostExpensiveF = mostExpensiveF;
	}

	public void setLeastExpensiveF(String leastExpensiveF) {
		this.leastExpensiveF = leastExpensiveF;
	}
	
	public void printFacilityDetails() {
		System.out.println("The total number of facilities this department has been involved with is " + numberofF);
		System.out.println("The most expensive facility is " + mostExpensiveF);
		System.out.println("and its details are");
		System.out.println("The least expensive facility is " + leastExpensiveF);
		System.out.println("and its details are");
		System.out.println(" ");
	}
}
