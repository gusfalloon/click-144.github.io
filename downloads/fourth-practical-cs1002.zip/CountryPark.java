
public class CountryPark {
	private String name = "Clear Water Bay Country Park";
	private String location = "Clear Water Bay, New Territories, Hong Kong";
	public String manager = "Mr. Arpit Panjabi";
	private double fee = 1000000000;

	public void printDetails() {
		System.out.println(name + ":");
		System.out.println("Location: " + location);
		System.out.println("Manager: " + manager);
		System.out.println("Entrance fee: " + "£" + fee);
		System.out.println(" ");
	}
	
	public String getName() {
		return name;
	}

	public String getLocation() {
		return location;
	}

	public String getManager() {
		return manager;
	}

	public double getFee() {
		return fee;
	}
	
}
