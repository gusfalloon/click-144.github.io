
public class Facility {
	
	private String name = "";
	private String location = "";
	private String type = "";
	private double cost = 0;
	
	public void setDetails(String name, String location, String type, double cost) {
		this.name = name;
		this.location = location;
		this.type = type;
		this.cost = cost;
	}
	
	public void printDetails() {
		System.out.println(name + ":");
		System.out.println("Location: " + location);
		System.out.println("Type: " + type);
		System.out.println("Cost: " + "£" + cost);
		System.out.println(" ");
	}
	

	public String getName() {
		return name;
	}
	
	public String getLocation() {
		return location;
	}
	
	public String getType() {
		return type;
	}
	
	public double getCost() {
		return cost;
	}
	
}
