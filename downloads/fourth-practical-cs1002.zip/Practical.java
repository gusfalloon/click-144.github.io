public class Practical {

	public static void main(String[] args) {
	
		CountryPark countrypark = new CountryPark();
		countrypark.printDetails();
		
		Department1 events = new Department1();
		Department2 facilities = new Department2();

			
		Facility sportsCentre = new Facility();
			sportsCentre.setDetails("Sports Centre", "The Club", "Indoors", 500);
			sportsCentre.printDetails();
			facilities.numberofF++;

		Facility restaurant = new Facility();
			restaurant.setDetails("The Club Restaurant", "The Club", "Indoors", 40);
			restaurant.printDetails();
			facilities.numberofF++;

			
		Facility golfCourse = new Facility();
			golfCourse.setDetails("The Old Course", "The Green", "Outdoors", 9000);
			golfCourse.printDetails();
			facilities.numberofF++;
		
		
		
		Event funRun = new Event();
			funRun.setDetails("Fun Run 2014", "A short, fun-filled blast of exercise that lasts 4km!", 1000);
			funRun.setDate("12/12/2014");
			funRun.printDetails();
			
		Event bakeSale = new Event();
			bakeSale.setDetails("Bake Sale 2014", "One for the kids: a bake sale!", 9000);
			bakeSale.setDate("11/10/2014");
			bakeSale.printDetails();
		
		Event christmasFair = new Event();
			christmasFair.setDetails("Christmas Fair 2014", "Our event of the year, please come along!", 20000);
			christmasFair.setDate("23/12/2014");
			christmasFair.printDetails();
			
		System.out.println(facilities.numberofF);
			
		facilities.requestNewFacility("Roller Coaster", 50000);
		facilities.requestNewFacility("Swinging Dinosaur", 949999);
		
		events.requestNewEvent("Christmas Carol", 600000);
		events.requestNewEvent("Date Night", 300000);
			
	}
}
