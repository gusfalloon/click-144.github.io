
public class Staff {
	
	private String name = "";
	private String description = "";
	private String address = "";
	private double salary = 0;
	
	public void setDetails(String name, String description, String  address, double salary) {
		this.name = name;
		this.description = description;
		this.address = address;
		this.salary = salary;
	}
	
	public void printDetails() {
		System.out.println(name + ":");
		System.out.println("Description: " + description);
		System.out.println("Address: " + address);
		System.out.println("Salary: " + "£" + salary);
		System.out.println(" ");
	}

	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public String getAddress() {
		return address;
	}
	
	public double getSalary() {
		return salary;
	}
		
}