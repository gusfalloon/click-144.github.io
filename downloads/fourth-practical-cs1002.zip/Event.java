
public class Event {
	
	private String name = "";
	private String description = "";
	private String date = "";
	private double cost = 0;
	
	public void setDetails(String name, String description, double cost) {
		this.name = name;
		this.description = description;
		this.cost = cost;
	}
	
	public void printDetails() {
		System.out.println(name + ":");
		System.out.println("Description: " + description);
		System.out.println("Date: " + date);
		System.out.println("Cost: " + "£" + cost);
		System.out.println(" ");
	}

	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public String getDate() {
		return date;
	}
	
	public double getCost() {
		return cost;
	}
	
	public void setDate(String date) {
		this.date = date;
	}
		
}