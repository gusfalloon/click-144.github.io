import static org.junit.Assert.*;

import org.junit.Test;


public class PracticalTest {

	private double budget;

	@Test
	public void test() {
		Department2 facilities = new Department2();
		budget = 1000000;
		facilities.requestNewFacility("Roller Coaster", 1000);
		assertEquals(budget, 999000, 1000);
	}

	
	@Test
	public void test2() {
		Department2 facilities = new Department2();
		budget = 1000000;
		facilities.requestNewFacility("Roller Coaster", 300000000);
		assertEquals(budget, 1000000, 0);
	}
	
}
