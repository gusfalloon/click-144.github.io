
public class Department1 {
	private String name = "Events";
	public String head = "Mr Beard";
	public String secretary = "Mr Wickins";
	private double budget = 900000;
	
	public int numberofE = 0;
	private String mostExpensiveE = " ";
	private String leastExpensiveE = " ";
	
	public void printDetails() {
		System.out.println(name + ":");
		System.out.println("Head: " + head);
		System.out.println("Secretary: " + secretary);
		System.out.println("Annual budget: " + "£" + budget);
		System.out.println(" ");
	}	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHead() {
		return head;
	}
	
	public void setHead(String head) {
		this.head = head;
	}

	public String getSecretary() {
		return secretary;
	}
	
	public void setSecretary(String secretary) {
		this.secretary = secretary;
	}

	public double getBudget() {
		return budget;
	}
	
	public void setBudget(double budget) {
		this.budget = budget;
	}
	
	public double requestNewEvent(String event, double cost) {
		double newBudget = budget - cost;
		if(cost > budget) {
			System.out.println("This event is not within our budget constraint, we are sorry.");
			System.out.println("");
			newBudget = budget - 0;
		}
		else if(cost <= budget) {
			System.out.println("Thank you, this event request has been granted.");
			System.out.println("");
			newBudget = budget - cost;
		}
		System.out.println("£" + newBudget);
		System.out.println("");
		budget = newBudget;
		return budget;
		
	}
	
	public void printEventDetails() {
		System.out.println("The total number of events this department has been involved with is " + numberofE);
		System.out.println("The most expensive event is " + mostExpensiveE);
		System.out.println("and its details are");
		System.out.println("The least expensive event is " + leastExpensiveE);
		System.out.println("and its details are");
		System.out.println(" ");
	}
	
}
