
public class EmptyFileException extends Exception {

	private static final long serialVersionUID = 1L;

	// Parameterless Constructor
	public EmptyFileException() {
		
	}
	
	// Constructor that accepts a message
	public EmptyFileException(String message) {
		super(message);
	}

}