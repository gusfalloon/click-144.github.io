import java.sql.*;
import java.util.*;
import java.io.*;


public class TableGenerator {

	private int ID = 1;
	final int recordForAge = 0;
	final int recordForOccupation = 1;
	final int recordForEducation = 2;
	final int recordForWage = 3;
	final int recordForFCob = 4;
	final int recordForMCob = 5;
	final int recordForCob = 6;
	final int recordForCitizen = 7;

	private static final String DB_URL = "jdbc:mysql://uuuu.mysql.cs.st-andrews.ac.uk/uuuu_db";
	private static final String DB_USERNAME = "uuuu";
	private static final String DB_PASSWORD = "xxxx";

	public static void main(String[] args) throws EmptyFileException, SQLException {
		TableGenerator generator = new TableGenerator();
		File file = new File("census-small.csv");
		System.out.println("Taking in the file and setting up! Will be just a sec.");
		System.out.println();
		generator.readMyFile(file);
	}

	void readMyFile(File input) throws SQLException, EmptyFileException {
		try {
			Connection connection = null; 
			connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
			Scanner scanner = new Scanner(input);        	

			if (scanner.hasNextLine() == false) {
				scanner.close();
				throw new EmptyFileException();
			}

			createTable(connection);

			scanner.nextLine();

			while (scanner.hasNextLine()) {
				String contents = scanner.nextLine();
				String delims = "[,]";
				contents = contents.trim();
				String[] elements = contents.split(delims);
				PreparedStatement statement = null;
				statement = connection.prepareStatement(makeRowInsertStatement(elements));
				try {					
					statement.execute();
				}
				catch (SQLException e) {
					System.out.println(e);
					statement = connection.prepareStatement("INSERT INTO Census VALUES();");      			
				}
				finally {
					if (statement != null)						
						statement.close();
				}
				//printAllData(statement);
			}
			
			printAllData(connection);
			Scanner scanner1 = new Scanner(System.in);
			System.out.println("Please enter a country for finding the occupation codes of all records where the individual "
					+ "was born in the input country");
			String inputCountry = scanner1.nextLine();
			scanner1.close();
			printCodeFromCountry(connection, inputCountry);
			printCobWithMother(connection);
			if (connection != null) {
				connection.close();
			}
			scanner.close();
		}
		catch (FileNotFoundException e){
			System.out.println("File not found: " + e.getMessage());
			System.out.println("Please scan in a new file.");
			Thread.currentThread().getStackTrace();
		}
		catch (EmptyFileException e) {
			System.out.println("The input file contains" + e.getMessage());
			System.out.println("Please scan in a new file.");
			Thread.currentThread().getStackTrace();
		}
	}

	//********************************************************************************************************
	private static void createTable(Connection connection) throws SQLException {

		Statement statement = null;
		try {
			statement = connection.createStatement();

			statement.executeUpdate("DROP TABLE IF EXISTS Census");
			statement.executeUpdate("CREATE TABLE Census (ID MEDIUMINT NOT NULL AUTO_INCREMENT, "
					+ "Age INT(11), Occupation_code INT(11), Education VARCHAR(40), "
					+ "Wage_per_hour INT(11), Father_Country_of_birth VARCHAR(40), Mother_Country_of_birth VARCHAR(40),"
					+ "Country_of_birth VARCHAR(40), Citizenship VARCHAR(45), PRIMARY KEY (id))");

		} finally {
			if (statement != null) statement.close();
		}
	}
	//********************************************************************************************************

	String makeRowInsertStatement (String[] elements) throws SQLException {
		String statementIntro = "INSERT INTO Census VALUES (";
		String statementClose = ");";
		String statement = Integer.toString(ID) + ",";
		
		for (int i = 0; i < elements.length; i++) {
			if (elements[i].getClass() != null) {
				if (i == recordForAge) {
					statement += elements[i] + ",";
				}
				else if (i == recordForOccupation) {
					statement += elements[i] + ",";
				}
				else if (i == recordForEducation) {
					statement += "\"" + elements[i] + "\"" + ",";
				}
				else if (i == recordForWage) {
					statement += elements[i] + ",";
				}
				else if (i == recordForFCob) {
					statement += "\"" + elements[i] + "\"" + ",";
				}
				else if (i == recordForMCob) {
					statement += "\"" + elements[i] + "\"" + ",";
				}
				else if (i == recordForCob) {
					statement += "\"" + elements[i] + "\"" + ",";
				}
				else if (i == recordForCitizen) {
					statement += "\"" + elements[i] + "\"";
				}
			}
		}		
		statement = statementIntro + statement + statementClose;
		ID++;
		return statement;
	}

	void printAllData(Connection connection) throws SQLException {

		Statement statement = null;
		try {
			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT * FROM Census");

			System.out.println("Contents of table:");
			while (resultSet.next()) {

				int id = resultSet.getInt("ID");
				int age = resultSet.getInt("Age");
				int code = resultSet.getInt("Occupation_code");
				String education = resultSet.getString("Education");
				int wage = resultSet.getInt("Wage_per_hour");
				String FCob = resultSet.getString("Father_Country_of_birth");
				String MCob = resultSet.getString("Mother_Country_of_birth");
				String Cob = resultSet.getString("Country_of_birth");
				String citizen = resultSet.getString("Citizenship");

				System.out.println("ID: " + id);
				System.out.println("Age: " + age);
				System.out.println("Occupation Code: " + code);
				System.out.println("Education: " + education);
				System.out.println("Wage: " + wage);
				System.out.println("Father's Country of birth: " + FCob);
				System.out.println("Mother's Country of birth: " + MCob);
				System.out.println("Country of birth: " + Cob);
				System.out.println("Citizenship: " + citizen);
				System.out.println();
			}
		} finally {
			if (statement != null) statement.close();
		}
	}

	void printCodeFromCountry (Connection connection, String countryName) throws SQLException {

		Statement statement = null;
		try {
			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT Occupation_code FROM Census WHERE Country_of_birth LIKE "
					+ "'%" + countryName + "%'" + ";");

			System.out.println("Contents of codeFromCountry query:\n");
			while (resultSet.next()) {
				int code = resultSet.getInt("Occupation_code");;
				System.out.println("Occupation Code: " + code);	
				System.out.println();
			}
		} finally {
			if (statement != null) statement.close();
		}
	}
	
	void printCobWithMother (Connection connection) throws SQLException {
		int i = 0;
		Statement statement = null;
		try {
			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT Country_of_birth FROM Census WHERE Mother_Country_of_birth LIKE Country_of_birth;");

			while (resultSet.next()) {
				i++;
			}
			System.out.println("The number of people born in the same country as their mother is: " + i);
		} finally {
			if (statement != null) statement.close();
		}
	}
}
