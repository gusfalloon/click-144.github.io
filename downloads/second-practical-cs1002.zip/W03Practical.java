import java.io.*;

class W03Practical {
	public static void main(String[] args){
	
	//Providing the costs of the individual items. 
	//As you can see, EasyIn methods were used to improve the usability of this program as a calculator.
	
	//This was me trying to be clever (and succeeding, thankfully). An 'if' statement was used to improve the quality of the program. 
	//I am aware that I am assuming the kids only want one birthday cake (although quite why you would need more than one is beyond me).

	System.out.println("Would you like a birthday cake? Please answer 'Yes' or 'No'");
	double cakeCost = 25.75;
	String cakeYes = EasyIn.getString();
		if (cakeYes.equals("No")){
		cakeCost = 0;
		}

	System.out.println("Please enter the number of plates of sandwiches you would like");
	byte sandwichesNumber = EasyIn.getByte();		//Bytes were used, since you're unlikely to ask for more than the limits of a byte anyway.
								//And less of a challenge for the computer! Doubles had to be used for the costs, though.
	double sandwichesCost = sandwichesNumber * 12.50;

	System.out.println("Please enter the number of plates of sausage rolls you would like");
	byte rollsNumber = EasyIn.getByte();
	double rollsCost = rollsNumber * 12.50;

	System.out.println("Please enter the number of plates of jelly and ice-cream you would like");
	byte jellyNumber = EasyIn.getByte();
	double jellyCost = jellyNumber * 13.75;

	//Do you really need more than one magician?

	System.out.println("Would you like a magician? Please answer 'Yes' or 'No'");
	double magicianCost = 67.99;
	String magicianYes = EasyIn.getString();
		if (magicianYes.equals("No")){
		magicianCost = 0;
		}

	System.out.println("Please enter the number of Pass the Parcel games you would like");
	byte parcelgameNumber = EasyIn.getByte();
	double parcelgameCost = parcelgameNumber * 17.10;
	
	System.out.println("Please enter the number of balloons you would like");
	byte balloonNumber = EasyIn.getByte();
	int balloonCost = balloonNumber * 1;
	
	System.out.println("Please enter the number of party bags you would like");
	byte partybagNumber = EasyIn.getByte();
	double partybagCost = partybagNumber * 2.50;

	System.out.println("Please enter the number of invitations you would like");
	byte invitationNumber = EasyIn.getByte();
	double invitationCost = invitationNumber * 1.30;

	//Again, as above, I'm guessing you only need one venue (although if you disagree, I'm open to new ideas).

	System.out.println("Would you like to book a venue? Please answer 'Yes' or 'No'");
	double venueCost = 99.99;
	String venueYes = EasyIn.getString();
		if (venueYes.equals("No")){
		venueCost = 0;
		}

	double foodTotal = cakeCost + sandwichesCost + rollsCost
	 + jellyCost;		// Adding up the costs in chunks to lighten the task of the computer

	double itemsandeventsTotal = magicianCost + parcelgameCost
	 + balloonCost + partybagCost + invitationCost;

	double totalCost = (foodTotal + itemsandeventsTotal + venueCost); //And giving the total cost...

	System.out.println("The cost of this party by Exorbitant Party Planners is " + "£" + totalCost);
	System.out.println("The cost of this party by Cheaper Parties would be " + "£" + (totalCost - 30)); //Well, it IS cheaper.
	}
}
