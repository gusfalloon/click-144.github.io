import galapagos.*;
import java.awt.Color;
import galapagos.TurtleDrawingWindow;


public class W02Practical {

    public static void main(String[] args){

	// Creating objects and window
	Turtle fred = new Turtle(0);
	Turtle sam = new Turtle(0);
	Turtle john = new Turtle(0);
	Turtle james = new Turtle(0);
	
	TurtleDrawingWindow drawing_area = new TurtleDrawingWindow();

	drawing_area.add(fred);
	drawing_area.add(sam);
	drawing_area.add(john);
	drawing_area.add(james);
	
	drawing_area.setVisible(true);
	drawing_area.setUnit(0.8);

	// Creating a curved 'D' character
	fred.penColor(Color.red);
	fred.penDown();
	fred.speed(100);
	fred.jumpTo(-300, -50);
		for(int i=1; i<15; i++){
			fred.move(22.5);
			fred.turn(15);
		}
	fred.penUp();
	fred.moveTo(-300, 100);
	fred.penDown();
	fred.moveTo(-300, -50);
	
	// Creating an 'A' character
	sam.bodyColor(Color.red);
	sam.penColor(Color.green);
	sam.penDown();
	sam.speed(100);
	sam.jumpTo(-200, -50);
	sam.moveTo(-150, 100);
	sam.moveTo(-100, -50);

	// Creating an 'S' character
	john.bodyColor(Color.blue);
	john.penColor(Color.blue);
	john.jumpTo(-25, 100);
	john.penDown();
	john.speed(100);
		for(int i=1; i<12; i++){
			john.move(-10);
			john.turn(15);
		}
		for(int i=1; i<15; i++){
			john.move(-10);
			john.turn(-15);
		}

	// Creating the number 1 (probably the hardest character of the lot!)
	james.bodyColor(Color.yellow);
	james.penColor(Color.yellow);
	james.penDown();
	james.speed(100);
	james.jumpTo(100, -87.5);
	james.moveTo(100, 137.5);

	// Creating the number 8
	james.penColor(Color.black);
	james.penUp();
	james.moveTo(220, 137.5);
	james.penDown();
		for(int i=1; i<28; i++){
			james.move(20);
			james.turn(-20);
		}
		for(int i=1; i<20; i++){
			james.move(20);
			james.turn(20);
		}
	
	john.penUp();
	john.moveTo(-175, 25);
	john.penColor(Color.green);
	john.penDown();
	john.moveTo(-125, 25);

	// "Fancy scribbling"
	fred.penUp();	
	fred.moveTo(-150, 0);
	fred.moveTo(300, 0);
	fred.penDown();
	fred.penColor(Color.green);
	fred.moveTo(400, 0);
	fred.moveTo(400, -150);
	fred.moveTo(-400, -150);
	fred.moveTo(-400, 0);
	fred.moveTo(-350, 0);
	
	sam.penUp();
	sam.moveTo(-150, 100);
	sam.moveTo(300, 100);
	sam.penDown();
	sam.penColor(Color.red);
	sam.moveTo(350, 100);
	sam.moveTo(350, 150);
	sam.moveTo(-350, 150);
	sam.moveTo(-350, 100);
	sam.moveTo(-350, 100);

	john.penUp();	
	john.moveTo(300, 50);
	john.penDown();
	john.penColor(Color.blue);
	john.moveTo(400, 50);
	john.moveTo(400, 200);
	john.moveTo(-400, 200);
	john.moveTo(-400, 50);
	john.moveTo(-350, 50);
	john.penUp();

	/* Creating the nifty circles at the bottom of the screen. A loop would have been easier, but I wasn't able to work out how to do it. The other turtles also malfunctioned when asked to join in... Which wasn't helpful.*/
	john.moveTo(-350, -220);
	john.penColor(Color.red);
	john.penDown();
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(20);
		}
	john.penColor(Color.blue);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(-20);
		}
	john.penColor(Color.green);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(20);
		}
	john.penColor(Color.yellow);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(-20);
		}
	john.penColor(Color.red);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(20);
		}
	john.penColor(Color.blue);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(-20);
		}
	john.penColor(Color.green);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(20);
		}
	john.penColor(Color.yellow);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(-20);
		}
	john.penColor(Color.red);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(20);
		}
	john.penColor(Color.blue);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(-20);
		}
	john.penColor(Color.green);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(20);
		}
	john.penColor(Color.yellow);
		for(int i=1; i<28; i++){
			john.move(10);
			john.turn(-20);
		}

	james.penUp();
	james.moveTo(300, -50);
	james.penDown();
	james.penColor(Color.yellow);
	james.moveTo(350, -50);
	james.moveTo(350, -100);
	james.moveTo(-350, -100);
	james.moveTo(-350, -50);
	james.moveTo(-350, -50);
	
	
    }
}
