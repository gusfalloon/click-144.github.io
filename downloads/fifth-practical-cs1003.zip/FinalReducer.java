package hadoop.wordcount;
import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

/*
 * And finally, the second reducer. It takes all the cases of '[Search string], int x' and adds all of the xs together.
 */
public class FinalReducer extends MapReduceBase implements Reducer<LongWritable, Text, Text, LongWritable> {

    // The output of the reducer is a map from the search string to its total count.

    public void reduce(LongWritable key, Iterator<Text> values, OutputCollector<Text, LongWritable> output, Reporter reporter) throws IOException {

        output.collect(values.next(), key);
        
    }
}
