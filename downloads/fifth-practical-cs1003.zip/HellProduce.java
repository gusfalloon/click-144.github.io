package hadoop.wordcount;			//Guess what project I borrowed off in a "liberal" manner? (Hint: it's in the name)
import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;

/*
 * @author [HAHAHAHA did you actually think I'd be silly enough to give my name up that easily? Sorry]
 * @version 1.0
 */

public class HellProduce {			//A piss-poor attempt at punning on MapReduce. Or should that be MapShuffleReduce?

	/*
	 * The main method retrieves user input and then processes said input to deliver a) a file containing instances 
	 * of the search string and b) a file with the search string and number of *individual* occurrences of that string.
	 */
	public static void main(String[] args) throws IOException {

		Scanner scanner = new Scanner(System.in);				  
		System.out.print("Please enter a word or expression to search the files for. The given word"
				+ "/expression will also be used when searching within a specific language.");
		System.out.println();
		String input = scanner.nextLine();					//Little explanation needed here.
		while (input.isEmpty() || input.equals(" ")) {
			System.out.println("Nuh-uh. Try again."); //Dealing with erroneous input
			input = scanner.nextLine();
		}
		System.out.println();
		System.out.print("Please enter a given language. If you don't enter anything or you enter something stupid,"
				+ " then the default will be English. This will be "
				+ "the same language used for the word frequencies."); //It responds to potential problems, don't judge me.
		System.out.println();
		String inputLanguage = scanner.nextLine();
		scanner.close();

		firstJob(input);
		secondJob(input, inputLanguage);
		thirdJob(input);	//No need for the language here.
		fourthJob(inputLanguage);	
		oneLastJob();	//I LOVED writing this method name. 
		System.out.println("The output file should contain the search string" +
				" and its frequency in the relevant language!");					
	}



	/*
	 * Configuring the first job (finding the search string regardless of language) and shifting the
	 * output into a single file.
	 * @param user input 
	 * @param input language
	 * @return void
	 */
	private static void firstJob(String input) throws IOException {
		JobConf job = new JobConf();
		job.set("inputString", input);

		FileInputFormat.setInputPaths(job, new Path("input"));
		FileOutputFormat.setOutputPath(job, new Path("output-0"));

		// Output from reducer maps sentences containing the search string to counts. 
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(LongWritable.class);

		// The output of the mapper is a map from lines containing the search string (including embedded cases 
		//(e.g. 'for' in 'thereFORe') to the number one.
		job.setMapperClass(FirstMapper.class);

		// The output of the reducer is really just to put the damn output into one file. Easier to deal with.
		job.setReducerClass(FirstReducer.class);

		JobClient.runJob(job);		//Release the hounds of hell...
	}

	/*
	 * Configuring the second job (finding the search string/language requirements) and shifting the
	 * output into a single file.
	 * @param user input 
	 * @param input language
	 * @return void
	 */
	private static void secondJob(String input, String inputLanguage) throws IOException {
		JobConf secondJob = new JobConf();
		secondJob.set("inputString", input);
		secondJob.set("inputLanguage", linguisticSwitch(inputLanguage));

		FileInputFormat.setInputPaths(secondJob, new Path("input"));
		FileOutputFormat.setOutputPath(secondJob, new Path("intermediate-0"));

		// Output from reducer maps sentences containing the search string to counts. 
		secondJob.setOutputKeyClass(Text.class);
		secondJob.setOutputValueClass(LongWritable.class);

		// The output of the mapper is a map from lines containing the search string (including embedded cases 
		//(e.g. 'for' in 'thereFORe') to the number one.
		secondJob.setMapperClass(SecondMapper.class);

		// The output of the reducer is really just to put the damn output into one file. Easier to deal with.
		secondJob.setReducerClass(SecondReducer.class);

		JobClient.runJob(secondJob);
	}

	/*
	 * Configuring the third job (finding the search string within the output file of the first map/reduce execution)
	 * and counting the number of occurrences of that word.
	 * @param user input 
	 * @return void
	 */
	private static void thirdJob(String input) throws IOException {
		JobConf thirdJob = new JobConf();
		thirdJob.set("inputString", input);	//Once again, configuring parameters.

		FileInputFormat.setInputPaths(thirdJob, new Path("intermediate-0"));	//Note the different paths in this job.
		FileOutputFormat.setOutputPath(thirdJob, new Path("output-1"));

		// Output from reducer maps the search string to its count.
		thirdJob.setOutputKeyClass(Text.class);
		thirdJob.setOutputValueClass(LongWritable.class);

		// The output of the mapper is a map of all instances of the search string to the value 1.
		thirdJob.setMapperClass(ThirdMapper.class);

		// The output of the reducer is a map from these instances to the total count.
		thirdJob.setReducerClass(ThirdReducer.class);

		JobClient.runJob(thirdJob);		//Same old story - 'what on Earth is actually going on', etc.
	}
	
	/*
	 * Configuring the last job (doing the word count with the given language)
	 * and counting the number of occurrences of that word.
	 * @param user input 
	 * @return void
	 */
	private static void fourthJob(String inputLanguage) throws IOException {
		JobConf fourthJob = new JobConf();
		fourthJob.set("inputLanguage", linguisticSwitch(inputLanguage));

		FileInputFormat.setInputPaths(fourthJob, new Path("input"));
		FileOutputFormat.setOutputPath(fourthJob, new Path("intermediate-1"));

		// Output from reducer maps the search string to its count.
		fourthJob.setOutputKeyClass(Text.class);
		fourthJob.setOutputValueClass(LongWritable.class);

		// The output of the mapper is a map of all instances of the search string to the value 1.
		fourthJob.setMapperClass(FourthMapper.class);

		// The output of the reducer is a map from these instances to the total count.
		fourthJob.setReducerClass(ThirdReducer.class);

		JobClient.runJob(fourthJob);
	}
	
	private static void oneLastJob() throws IOException {
		JobConf lastJob = new JobConf();

		FileInputFormat.setInputPaths(lastJob, new Path("intermediate-1"));
		FileOutputFormat.setOutputPath(lastJob, new Path("output-2"));
		
        lastJob.setMapOutputKeyClass(LongWritable.class);
        lastJob.setMapOutputValueClass(Text.class);
		
		// Output from reducer maps the search string to its count.
		lastJob.setOutputKeyClass(Text.class);
		lastJob.setOutputValueClass(LongWritable.class);

		// The output of the mapper is a map of all instances of the search string to the value 1.
		lastJob.setMapperClass(FinalMapper.class);

		// The output of the reducer is a map from these instances to the total count.
		lastJob.setReducerClass(FinalReducer.class);
		lastJob.setOutputKeyComparatorClass(LongWritable.DecreasingComparator.class);
		
		JobClient.runJob(lastJob);
	}
	
	/*
	 * The switch statement required to get the correct language, shuffled neatly into the corner in a (really ugly) 
	 * method.
	 * @param input language
	 * @return String
	 */
	private static String linguisticSwitch(String inputLanguage) {
		inputLanguage = inputLanguage.toLowerCase();
		String processedLanguage = "EN-GB";			//Had to initialise it - so I put English to be safe.
		switch (inputLanguage) {
		case "english": processedLanguage = "EN-GB"; break;
		case "german": processedLanguage = "DE-DE"; break;
		case "french": processedLanguage = "FR-FR"; break;
		case "danish": processedLanguage = "DA-01"; break;
		case "greek": processedLanguage = "EL-01"; break;
		case "spanish": processedLanguage = "ES-ES"; break;
		case "finnish": processedLanguage = "FI-01"; break;
		case "italian": processedLanguage = "IT-IT"; break;
		case "dutch": processedLanguage = "NL-NL"; break;
		case "portuguese": processedLanguage = "PT-PT"; break;
		case "swedish": processedLanguage = "SV-SE"; break; 		//A very ugly swtich statement, but it's more compact
		case "latvian": processedLanguage = "LV-01"; break;			//this way. Alas, the price of user-friendliness.
		case "czech": processedLanguage = "CS-01"; break;			//My altruism *laughs* is at but a price.
		case "estonian": processedLanguage = "ET-01"; break;
		case "hungarian": processedLanguage = "HU-01"; break;
		case "polish":processedLanguage = "PL-01"; break;
		case "slovenian": processedLanguage = "SL-01"; break;
		case "lithuanian": processedLanguage = "LT-01"; break;
		case "maltese": processedLanguage = "MT-01"; break;
		case "slovak": processedLanguage = "SK-01"; break;
		case "romanian":processedLanguage = "RO-RO"; break;
		case "bulgarian": processedLanguage = "BG-01"; break;
		default: processedLanguage = "EN-GB"; break;				//Just in case you're cruel enough to give me silly
		}															//input!
		System.out.println();
		return processedLanguage;
	}
}
