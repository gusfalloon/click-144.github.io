package hadoop.wordcount;
import java.io.IOException;
import java.util.Scanner;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

/*
 * The first mapper, which maps lines containing the search string (within the legislation tags for the input language)
 * to the number one.
 */
public class FirstMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, LongWritable> {

	private String inputString; 				//Fairly standard fare regarding fields. 

	@Override
	/*
	 * Overriding the configure method and retrieving the user input string and language back from the job.
	 * @param job
	 */
	public void configure(JobConf job) { 			//And do you call this method at any stage? No - which feels 
		inputString = job.get("inputString"); 		//really, really weird actually.
	}

	/*
	 * The map method that checks for the correct language 'block' and then checks within that block for the given
	 * string. Then outputs the line if it contains the search string and the number one.
	 */
	public void map(LongWritable key, Text value, OutputCollector<Text, LongWritable> output, 
			Reporter reporter) throws IOException {

		// The key is the character offset within the file of the start of the line, ignored.
		// The value is a line from the file.		

		String line = value.toString();
		Scanner scanner = new Scanner(line);

		while (scanner.hasNext()) {
			String word = scanner.next();
			if (line.contains("<seg>") && line.contains("</seg>")) {
				if (word.equalsIgnoreCase(inputString)) { 	//A variety of conditions to make sure of the correct language, etc.
					output.collect(new Text(line), new LongWritable(1));
				}
			}
		}
		scanner.close(); //Closing the scanner like a good computer scientist!
	}
}
