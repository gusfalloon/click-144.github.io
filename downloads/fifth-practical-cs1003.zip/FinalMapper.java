package hadoop.wordcount;
import java.io.IOException;
import java.util.Scanner;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class FinalMapper extends MapReduceBase implements Mapper<LongWritable, Text, LongWritable, Text> {

    // The mapper reads a map from unique words to counts.
    // The output of the mapper is a map from counts (including duplicates) to words.

    public void map(LongWritable key, Text value, OutputCollector<LongWritable, Text> output, Reporter reporter) throws IOException {

        // The key is the character offset within the file of the start of the line, ignored.
        // The value is a line from the file.

        String line = value.toString();
        Scanner scanner = new Scanner(line);

        // The first token on the line is the word, and the second is the count.

        Text word = new Text(scanner.next());
        LongWritable count = new LongWritable(Integer.parseInt(scanner.next()));

        // The count now becomes the key, since the data needs to be sorted by decreasing
        // count before the final reducer is applied.
        output.collect(count, word);
        scanner.close();
    }
}