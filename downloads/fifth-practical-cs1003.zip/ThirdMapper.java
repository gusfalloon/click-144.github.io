package hadoop.wordcount;
import java.io.IOException;
import java.util.Scanner;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

/*
 * The second mapper, which maps the search string to the number of times it's found in the scanned line.
 */
public class ThirdMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, LongWritable> {

	private String inputString;

	@Override
	/*
	 * Overriding the configure method and retrieving the user input string back from the job.
	 * @param job
	 */
	public void configure(JobConf job) { 
		inputString = job.get("inputString"); 
	}
	
	public void map(LongWritable key, Text value, OutputCollector<Text, LongWritable> output, 
			Reporter reporter) throws IOException {
		
		// The key is the character offset within the file of the start of the line, ignored.
        // The value is a line from the file.

        String line = value.toString();
        Scanner scanner = new Scanner(line);
        int sum = 0;
        char sumChar = line.charAt(line.length() - 1);	//Just retrieving the number at the end of the line which denotes the
        String sumString = Character.toString(sumChar);	//number of times the search string was found. From char to String to int.
        sum = Integer.parseInt(sumString);
        output.collect(new Text(inputString), new LongWritable(sum));   

        scanner.close();
	}
	
}